﻿# Networking Security Checklist

## Tokens

- [x] Authorization header adapter exists
- [x] Token clearing exists
- [ ] Tokens are never logged
- [ ] Token redaction is applied in observability
- [ ] Refresh token is not exposed to unrelated modules
- [ ] Browser storage risk is documented
- [ ] Mobile tokens use secure platform storage

## Refresh Flow

- [ ] Single-flight refresh concurrency
- [ ] Failed-request replay
- [ ] Refresh recursion prevention
- [ ] Refresh-token rotation support
- [ ] Replay detection handling
- [ ] Session invalidation callback

## Retries

- [ ] Maximum retry count enforced
- [ ] Exponential backoff
- [ ] Jitter
- [ ] Non-idempotent requests excluded by default
- [ ] 401 refresh flow separated from generic retries

## Interceptors

- [x] Request interceptor exists
- [x] Authorization interceptor exists
- [x] Response interceptor exists
- [x] Error interceptor exists
- [ ] Interceptor registration is idempotent
- [ ] Interceptor IDs can be ejected in tests/hot reload
- [ ] Duplicate interceptor registration is prevented

## Storage

- [x] Browser token storage adapter is isolated
- [ ] Production browser strategy reviewed against XSS threat model
- [ ] Secure cookie option evaluated
- [ ] Mobile secure storage implemented
- [ ] Storage failures handled

## GraphQL

- [x] Separate GraphQL client exists
- [x] GraphQL base query exists
- [ ] GraphQL `errors[]` normalized into the common error model
- [ ] Partial-data behavior documented
- [ ] Sensitive query variables are not logged

## Cancellation

- [ ] AbortSignal support
- [ ] RTK Query cancellation forwarded to Axios
- [ ] Streaming cancellation support
- [ ] Unmounted requests are canceled where needed

## Logging

- [x] No logging is required for token storage
- [ ] Authorization headers redacted
- [ ] Cookies redacted
- [ ] Sensitive request bodies redacted
- [ ] Password and reset-token fields redacted
- [ ] Production logs exclude raw Axios errors when sensitive data may exist

## Result

Status: Sprint 0 networking foundation is structurally complete, but authentication security orchestration remains intentionally deferred.

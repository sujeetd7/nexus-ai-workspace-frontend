﻿# CI Security Checklist

## Permissions

- [x] Workflow declares `contents: read`
- [ ] No job has unnecessary write permissions
- [ ] Future release workflows use separate permissions
- [ ] Fork pull requests cannot access protected secrets

## Actions

- [x] Official actions are used
- [x] Action major versions are pinned
- [ ] Actions are pinned to immutable commit SHAs
- [ ] Dependabot monitors GitHub Actions

## Execution Controls

- [x] Concurrency cancellation is configured
- [x] Job timeout is configured
- [x] Frozen lockfile installation is enforced
- [x] Dependency-policy validation is enforced
- [x] Lint, typecheck, tests, and builds run in CI

## Cache Safety

- [x] pnpm cache uses the lockfile
- [x] `node_modules` is not cached directly
- [ ] Cache poisoning risks reviewed for forked pull requests
- [ ] Restore keys are not overly broad

## Secrets

- [x] Quality workflow requires no secrets
- [ ] Future deployment secrets use GitHub Environments
- [ ] Secrets are never printed
- [ ] Sonar token is added only when scanner integration is enabled

## Artifacts

- [x] Quality workflow does not upload unnecessary artifacts
- [ ] Future artifacts define explicit retention periods
- [ ] Release artifacts use checksums/signing
- [ ] APK/AAB signing is isolated from pull-request workflows

## Branch Protection Readiness

- [ ] Workflow is required for protected branches
- [ ] Direct pushes are restricted
- [ ] Pull-request review is required
- [ ] CODEOWNERS review is required where appropriate
- [ ] Stale approvals are dismissed after new commits

## Result

Status: Ready for quality CI; additional hardening required before release CI/CD.

﻿# Architecture Decision Record Index

| ADR | Decision | Status |
|---|---|---|
| ADR-0001 | pnpm and TurboRepo monorepo | Accepted |
| ADR-0002 | Standardize Node.js 22.22.2 | Accepted |
| ADR-0003 | Isolate React Native ESLint | Accepted |
| ADR-0004 | Defer Storybook | Accepted |

## ADR Rules

- ADRs are immutable after acceptance.
- Material changes require a new ADR.
- Superseded ADRs remain in the repository with updated status.
- Architecture-affecting Sprint 1 changes require CTO review.

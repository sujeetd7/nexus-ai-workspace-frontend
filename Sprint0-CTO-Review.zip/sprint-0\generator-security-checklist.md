﻿# Generator Security Checklist

## Implemented Controls

- [x] Input names are validated
- [x] Path traversal is rejected
- [x] Overwrite is blocked by default
- [x] `--force` is explicit
- [x] `--dry-run` does not write files
- [x] Unsupported generators fail
- [x] Generator tests cover core behavior
- [x] Non-zero failure behavior is expected

## Required Security Validation

### Traversal

- [x] Reject `../`
- [x] Resolve paths against repository root
- [ ] Confirm encoded and mixed-separator traversal is rejected

### Absolute Paths

- [ ] Reject drive-rooted paths such as `C:\`
- [ ] Reject UNC paths
- [ ] Reject POSIX absolute paths
- [ ] Allow absolute paths only through an explicit future policy

### Symlinks

- [ ] Detect symlink/reparse-point destinations
- [ ] Prevent writes escaping the repository through symlinks
- [ ] Use real-path validation before writes

### Reserved Filenames

- [ ] Reject Windows reserved names such as `CON`, `PRN`, `AUX`, `NUL`
- [ ] Reject names ending in a dot or space
- [ ] Reject invalid cross-platform filename characters

### Overwrite Safety

- [x] Existing files are protected
- [ ] `--force` must not overwrite unrelated files
- [ ] Barrel updates must avoid duplicate exports

### Atomic Generation

- [ ] Generate into a temporary directory
- [ ] Validate all output before commit
- [ ] Move files atomically when possible
- [ ] Roll back partial writes after failure

### Determinism

- [x] Naming transformations are tested
- [ ] File ordering is deterministic
- [ ] Barrel export ordering is deterministic
- [ ] Generated content is stable across platforms
- [ ] Tests verify identical output for identical input

## Result

Status: Core safety exists, but symlink, reserved-name, atomic-write, and determinism hardening remain technical debt.
